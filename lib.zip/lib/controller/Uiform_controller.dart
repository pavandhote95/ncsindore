import 'package:cuickdevuser/controller/tableview_controller.dart';
import 'package:cuickdevuser/model/form_response.dart';
import 'package:cuickdevuser/service/httpservice.dart';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../service/apihelper.dart';

class Uiformcontroller extends GetxController {
  var workingDays = ''.obs;
  var PerDaySalary = ''.obs;
  var days = ''.obs;
  var sundays = ''.obs;
  var saturdays = ''.obs;


  void updateExpressionFields() {
    for (var field in labellist) {
      if (field['type'] == 'expression') {
        String expression = field['expression'] ?? field['rule'] ?? '';
        if (expression.isNotEmpty) {
          calculateAndSetExpression(field, expression);
        }
      }
    }
  }

  Future<void> calculateAndSetExpression(
      Map<String, dynamic> field, String expression) async {
    try {
      String fieldLabel = field['label'];
      String fieldCode = field['code'];

      print('🟡 CALCULATING for: $fieldLabel');
      print('🟡 Expression: "$expression"');

      String calculatedValue = await calculateExpression(expression);

      print('🟡 Calculated result: "$calculatedValue"');

      setFieldValue(fieldLabel, calculatedValue);
      dataMap[fieldCode] = calculatedValue;

      print('🟡 Value set: $fieldLabel = $calculatedValue');

      update();
    } catch (e) {
      print('🟡 Error: $e');
    }
  }

  String formatNumber(double number) {
    // Check if it's a whole number
    if (number % 1 == 0) {
      return number.toInt().toString();
    } else {
      // Format with 3 decimal places but trim trailing zeros
      return number
          .toStringAsFixed(3)
          .replaceAll(RegExp(r'0+$'), '')
          .replaceAll(RegExp(r'\.$'), '');
    }
  }

  Future<String> calculateExpression(String expression) async {
    print('🧮 PARSE EXPRESSION: "$expression"');

    try {
      if (expression.isEmpty) return '';

      String calculatedExpression = expression;
      final fieldPattern = RegExp(r'@(\w+)');
      final matches = fieldPattern.allMatches(calculatedExpression);

      print('🧮 Found ${matches.length} field references');

      for (final match in matches) {
        final fieldName = match.group(1);
        print('🧮 Looking for field: "$fieldName"');

        if (fieldName != null) {
          String? fieldValue = getFieldValueByCodeOrLabel(fieldName);
          print('🧮 Found value: "$fieldValue"');

          // 🔥 FIX: Check if it's second expression
          bool isSecondExpression = expression.contains('@Number') &&
              expression.contains('@Decimal') &&
              expression.contains('*2');

          if (fieldName.toLowerCase() == 'decimal') {
            if (fieldValue == null ||
                fieldValue.isEmpty ||
                fieldValue == "null") {
              if (isSecondExpression) {
                // 🎯 SECOND EXPRESSION: Decimal empty → 0 use karo
                calculatedExpression =
                    calculatedExpression.replaceAll('@$fieldName', '0');
                print('🧮 Second Expression - Decimal empty, using 0');
              } else {
                // FIRST EXPRESSION: Decimal empty → 1 use karo
                calculatedExpression =
                    calculatedExpression.replaceAll('@$fieldName', '1');
                print('🧮 First Expression - Decimal empty, using 1');
              }
            } else {
              String trimmed = fieldValue.trim();
              if (trimmed.isEmpty) {
                if (isSecondExpression) {
                  calculatedExpression =
                      calculatedExpression.replaceAll('@$fieldName', '0');
                } else {
                  calculatedExpression =
                      calculatedExpression.replaceAll('@$fieldName', '1');
                }
              } else if (double.tryParse(trimmed) != null) {
                calculatedExpression =
                    calculatedExpression.replaceAll('@$fieldName', trimmed);
              } else {
                if (isSecondExpression) {
                  calculatedExpression =
                      calculatedExpression.replaceAll('@$fieldName', '0');
                } else {
                  calculatedExpression =
                      calculatedExpression.replaceAll('@$fieldName', '1');
                }
              }
            }
          } else {
            // Number field handling
            if (fieldValue == null ||
                fieldValue.isEmpty ||
                fieldValue == "null") {
              calculatedExpression =
                  calculatedExpression.replaceAll('@$fieldName', '0');
            } else {
              String trimmed = fieldValue.trim();
              if (trimmed.isEmpty) {
                calculatedExpression =
                    calculatedExpression.replaceAll('@$fieldName', '0');
              } else if (double.tryParse(trimmed) != null) {
                calculatedExpression =
                    calculatedExpression.replaceAll('@$fieldName', trimmed);
              } else {
                calculatedExpression =
                    calculatedExpression.replaceAll('@$fieldName', '0');
              }
            }
          }
          print('🧮 After replacement: "$calculatedExpression"');
        }
      }

      double? result = _evaluateMathExpression(calculatedExpression);

      if (result != null) {
        String formattedResult;

        if (result == result.roundToDouble()) {
          formattedResult = result.round().toString();
          print('🧮 Integer result: $formattedResult');
        } else {
          formattedResult = result.toStringAsFixed(3);
          formattedResult = removeTrailingZeros(formattedResult);
          print('🧮 Decimal result: $formattedResult');
        }

        return formattedResult;
      }

      return '';
    } catch (e) {
      print('🧮 Error: $e');
      return '';
    }
  }

// Helper function to remove trailing zeros
  String removeTrailingZeros(String value) {
    if (value.isEmpty) return '';
    if (!value.contains('.')) return value;

    value = value.replaceAll(RegExp(r'0+$'), '');
    if (value.endsWith('.')) {
      value = value.substring(0, value.length - 1);
    }
    return value;
  }
// Helper function to remove trailing zeros

  var appurl = "".obs;
  var pagetitle = "".obs;
  var code = "".obs;
  var appCode = "".obs;
  var collectionName = "".obs;
  var applicationurl = "".obs;
  var saveformcode = "".obs;
  var saveform_id = 0.obs; // Making it observable
  var userstoryName = "".obs;
  var imagePaths = <String, String?>{}.obs;
  var docPaths = <String, String?>{}.obs;
  var resulterror = <String, String?>{}.obs;
  var uploadimage = <String, String?>{}.obs;
  var uploadDocument = <String, String?>{}.obs;
  var isLoading = false.obs;
  HttpServices httpServices = HttpServices();
  String? admissionId;
  RxList<Button> buttons = <Button>[].obs;
  RxList<Field> fields = <Field>[].obs;
  RxList<GroupLabels> grouplabellist = <GroupLabels>[].obs;
  Map<String, dynamic> dataMap = {};
  RxList<dynamic> labellist = RxList<dynamic>();
  RxList<dynamic> uniquefilteredList = RxList<dynamic>();
  RxList<dynamic> preloadparentUsecases = RxList<dynamic>();
  RxList<dynamic> uniquelist = RxList<dynamic>();
  RxMap<String, List<dynamic>> prelaodlist = RxMap<String, List<dynamic>>();
  RxList<dynamic> filterlabellist = RxList<dynamic>();
  List<String> globalYUsecases = [];
  Map<String, dynamic>? previousResponse;
  RxMap<String, String> initialValues = <String, String>{}.obs;
  final List<String> allowedTypes = [
    'text',
    'date',
    'number',
    'object',
    'email',
    'time',
    'url',
    'map',
    'textarea'
  ];
  final RxMap<String, String> _fieldValues = <String, String>{}.obs;
  final TableviewController viewcontroller = Get.put(TableviewController());
  final TextEditingController latController = TextEditingController();
  final TextEditingController longController = TextEditingController();
  updateappurl(
    var menutitle,
    var appurldata,
  ) {
    appurl.value = appurldata;
    pagetitle.value = menutitle;
  }

  final RxBool showTextField = false.obs;
  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
  }

  Map<String, bool> fieldRequiredMap = {};
  Map<String, String> fieldCodeMap = {};
  bool validateLocationField(
      {required bool requiredField, required String fieldCode}) {
    final lat = latController.text.trim();
    final lng = longController.text.trim();

    if (requiredField && (lat.isEmpty || lng.isEmpty)) {
      resulterror[fieldCode] = 'Please set the location';
      return false;
    } else {
      resulterror.remove(fieldCode);
      return true;
    }
  }

  @override
  void onClose() {
    // Dispose all TextEditingControllers
    latController.dispose();
    longController.dispose();
    imagePaths.clear();
    docPaths.clear();
    uploadimage.clear();
    uploadDocument.clear();
    _fieldValues.clear();
    dataMap.clear();
    previousResponse = null;

    super.onClose();
  }

  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    saveform_id.value = 0;
  }

  void clearForm() {
    saveform_id.value = 0;
    resulterror.clear();
    dataMap.clear();
    previousResponse = null;

    imagePaths.clear();
    docPaths.clear();
    uploadimage.clear();
    uploadDocument.clear();
    latController.clear();
    longController.clear();
    showTextField.value = false;

    _fieldValues.clear();
    initialValues.clear();

    // Re-apply default values immediately
    for (var item in labellist) {
      String fieldCode = item['code'] ?? '';
      String fieldLabel = item['label'] ?? '';
      String? defaultValue = item['defaultValue'];

      if (defaultValue != null && defaultValue.isNotEmpty) {
        setFieldValue(fieldLabel, defaultValue);
        dataMap[fieldCode] = defaultValue;
      }
    }

    if (viewcontroller.appurl.isNotEmpty) {
      viewcontroller.GetForm_API(viewcontroller.appurl.value);
    }

    viewcontroller.CurrentPage.value = 0;
    Get.find<TableviewController>().update();
    update();
  }

  void clearInitialValue(String code) {
    initialValues.remove(code);
    dataMap.remove(code);
    update();
  }

  var isuserFilter = 0.obs;

  Future<void> getuser_role_access(String formID) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String applicationRoleId = prefs.getString("applicationRoleId") ?? '';

    var res = await httpServices.getUserAccess(
      formId: formID,
      applicationRoleId: applicationRoleId,
    );

    if (res != null && res['success'] == true) {
      var userAccesslist = res['result']['data'];

      if (userAccesslist.isNotEmpty) {
        var firstAccess = userAccesslist[0]; // Get first index

        isuserFilter.value = firstAccess['userFilter'] ?? 0; // If available
      } else {}
    } else {}
  }

  Future<Map<String, dynamic>?> Savecomboitem(String formID, var value) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String sessionId = prefs.getString('jsessionid') ?? '';

    if (sessionId.isEmpty) {
      debugPrint("Session ID is missing.");
    }
    print('Savecomboitem====formID==========>${formID}');
    print('Savecomboitem====value==========>${value}');

    try {
      final response = await httpServices.tagitemsave(
          label: "Combobox",
          type: "combobox",
          userstoryId: viewcontroller.userstortyid.value
              .toString(), // Ensure it's an int
          id: formID, // Ensure it's an int
          values: value);

      if (response != null && response['success'] == true) {
        print('SaveTag====Combobox==========>${response}');

        return response;
      } else {
        return response;
      }
    } catch (e) {
      return {'message': 'Error occurred while saving the form'};
    }
  }

  dynamic getInitialValues(String fieldCode, String label) {
    // print('Fetching initial value for field code: $fieldCode');
    if (dataMap.containsKey(fieldCode)) {
      var value = dataMap[fieldCode];
      setFieldValue(label, value.toString());
      if (value is int) {
        setFieldValue(label, value.toString());
        return value.toString();
      }
      return value;
    }
    return null;
  }

  void setInitialValue(String code, String value) {
    initialValues[code] = value;
    update();
  }

  String? getFieldValue(String label) {
    return _fieldValues[label];
  }
  // final controllers = <String, TextEditingController>{}.obs;

  void setFieldValue(String label, dynamic value) {
    // print('=======label===========$label');
    // print('=======value===========$value');
    _fieldValues[label] = value;
    update();
  }

  Future<void> GetForm_API(String id) async {
    buttons.clear();
    grouplabellist.clear();
    fields.clear();
    var res = await httpServices.GetForm(formId: id);
    if (res?.success == true) {
      var data = res?.data;
      saveformcode.value = data!.code.toString();
      userstoryName.value = data.userstoryName.toString();
      buttons.assignAll(data.buttons);
      fields.assignAll(data.fields);
      grouplabellist.assignAll(data.groupLabels);
      await Getitemcode(data.userstoryId.toString());
      await Getattributefield(data.userstoryId.toString());

      update();
    } else {}
  }

  var usecase;
  final ApiBaseHelper helper = ApiBaseHelper();
  Future Getseachdata() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String sessionId = prefs.getString('jsessionid') ?? '';

    if (sessionId.isEmpty) {
      return {'success': false, 'message': 'Session ID is missing'};
    }

    Map<String, dynamic> reqBody = {};

    //  Loop through fields and add valid values to payload
    for (var field in filterlabellist) {
      var fieldValue = getFieldValue(field['label']);

      if ((fieldValue is String && fieldValue.isNotEmpty) ||
          (fieldValue is int && fieldValue != 0)) {
        dynamic formattedValue = fieldValue;

        if (field['refKey'] == 1 &&
            RegExp(r'^\d+$').hasMatch(fieldValue.toString())) {
          formattedValue = int.parse(fieldValue.toString());
        }

        reqBody[field['code']] = formattedValue;
      }
    }

    try {
      final response = await helper.postApi(
        "api/v1/${appCode.value}/${code.value}/search;jsessionid=$sessionId",
        reqBody,
      );

      if (response != null && response['success'] == true) {
        var dataResponse = response['result']['data'] as List;

        print("dataResponse............................... ${dataResponse}");

        if (response != null && response['success'] == true) {
          var dataResponse = response['result']['data'] as List;

          if (dataResponse.isNotEmpty) {
            final record = dataResponse[0] as Map<String, dynamic>;
            dataMap.assignAll(record);
            for (var group in grouplabellist) {
              var allFields = getGroupsField(group.label);
              for (var field in allFields) {
                String label = field['label'];
                String code = field['code'];

                if (record.containsKey(code)) {
                  String value = record[code]?.toString() ?? "";

                  // Save in controller
                  setFieldValue(label, value);
                  setInitialValue(code, value);
                  dataMap[code] = value;

                  update();
                }
              }
            }
          }

          update(); // Notifies UI to rebuild
          return response;
        }

        update(); // Trigger GetX UI update
        return response;
      }
    } catch (e) {
      return {
        'success': false,
        'message': 'Error occurred while saving the form'
      };
    }
  }

  dynamic getInitialValue(String fieldCode) {
    // print('Fetching initial value for field code: $fieldCode');
    if (dataMap.containsKey(fieldCode)) {
      var value = dataMap[fieldCode];

      if (value is int) {
        setFieldValue(fieldCode, value.toString());
        return value.toString();
      }
      return value;
    }
    return null;
  }

  Future<void> Getitemcode(String formid) async {
    var res = await httpServices.GetListusecase(
      id: formid,
    );

    if (res != null && res['success'] == true) {
      var dataResponse = res['result']['data']; // Cast to List<dynamic>
      usecase = dataResponse;
      if (dataResponse['parentUsecases'] is Map<String, dynamic>) {
        // Convert the map to a list of entries
        preloadparentUsecases.assignAll(
          dataResponse['parentUsecases'].entries.map((entry) {
            return {'key': entry.key, 'value': entry.value};
          }).toList(),
        );
      } else if (dataResponse['parentUsecases'] is List) {
        // If already a list, directly assign
        preloadparentUsecases.assignAll(dataResponse['parentUsecases']);
      } else {}

      code.value = dataResponse['code'];
      appCode.value = dataResponse['appCode'];
      collectionName.value = dataResponse['collectionName'];
      // uniquelist.addAll(dataResponse['unique'][0] ?? []);

      update();
    } else {}
  }

  void onChange(Map<String, dynamic> e, dynamic val) {
    final primaryUsecase = e['primaryUsecase'];
    final depAttribute = e['depAttribute'];

    final List<dynamic>? l = prelaodlist[primaryUsecase];
    if (l == null) return;

    for (var item in l) {
      if (item['id'] == val) {
        fields[depAttribute] = item['name'];
        break;
      }
    }
    // Check for dependency filter
    if (usecase != null &&
        usecase['parentUsecaseDependency'] != null &&
        usecase['parentUsecaseDependency'][primaryUsecase] != null) {
      primaryUsecaseDependencyFilter(
        usecase['parentUsecaseDependency'][primaryUsecase],
        val,
      );
    }
  }

  void primaryUsecaseDependencyFilter(
      Map<String, dynamic> data, dynamic val) async {
    final code = data['id']; // e.g., "componentNameId"
    final codeVALUE = data['code']; // e.g., "componentNameId"

    // Combine as required
    String formattedVal = "$code=$val";
    final paracode = data['code'];
    if (paracode == null) return;

    final parts = paracode.toString().split('.');
    if (parts.length < 2) return;

    final appCode = parts[0];
    final codes = parts[1];
    getdata(
      appCode,
      codes,
      formattedVal,
    );
  }

  Future<void> getdata(String appcode, String code, String filterParams) async {
    try {
      var response = await httpServices.getParentFilterData(
        appCode: appcode,
        hrStatus: code,
        val: filterParams,
      );

      if (response?['success'] == true) {
        var useCases = globalYUsecases;
        var result = response?['result'];

        for (var useCase in useCases) {
          if (result.containsKey(useCase)) {
            var data = result[useCase];

            if (data is List) {
              // Replace old list with new incoming data
              prelaodlist[useCase] = List.from(data);

              debugPrint(
                  'prelaodlist[$useCase] updated with ${data.length} items');
            }
          }
        }

        update();
      }
    } catch (e) {
      debugPrint('Error calling API: $e');
    }
  }

  Future<void> Getattributefield(String formId) async {
    labellist.clear();
    var res = await httpServices.Getlistattribute(formId: formId);
    if (res!['success'] == true) {
      var filteredList = res['result']['data'];
      var sortedFilteredList = filteredList.where((label) {
        return fields
            .any((field) => field.id.toString() == label['id'].toString());
      }).toList();

      sortedFilteredList.sort((a, b) {
        int indexA = fields
            .indexWhere((field) => field.id.toString() == a['id'].toString());
        int indexB = fields
            .indexWhere((field) => field.id.toString() == b['id'].toString());
        return indexA.compareTo(indexB);
      });

      // Add the `show` field to the sortedFilteredList
      for (var item in sortedFilteredList) {
        var matchingField = fields.firstWhere(
          (field) => field.id.toString() == item['id'].toString(),
        );

        if (matchingField != "") {
          item['show'] =
              matchingField.show ?? ''; // Add the `show` field from `fields`
          item['group'] =
              matchingField.group ?? ''; // Add the `show` field from `fields`
          item['event'] = matchingField.event ?? '';
          item['rule'] = matchingField.rule ?? '';
          item['label'] = matchingField.label ?? '';
          item['parentFilter'] = matchingField.parentFilter ?? '';
        }

        // 🎯 LOGIC TO APPLY DEFAULT VALUE 🎯
        String fieldCode = item['code'] ?? '';
        String fieldLabel = item['label'] ?? '';
        String? defaultValue = item['defaultValue'];

        // Only apply defaultValue if it exists, is not empty, and the field
        // has NOT been pre-loaded with existing data (dataMap check).
        if (defaultValue != null &&
            defaultValue.isNotEmpty &&
            !dataMap.containsKey(fieldCode)) {
          // 1. Set the value in the live field values map (_fieldValues)
          setFieldValue(fieldLabel, defaultValue);

          // 2. Set the value in the data map (used for submission/conditions)
          dataMap[fieldCode] = defaultValue;
        }
        // 🎯 END LOGIC 🎯
      }

      if (sortedFilteredList.isNotEmpty) {
        labellist.assignAll(sortedFilteredList);
      } else {}

      var uniqueUsecases = <String>{};
      for (var dashboardItem in labellist) {
        String yUsecase = dashboardItem['primaryUsecase'] ?? "";

        if (yUsecase.isNotEmpty) {
          uniqueUsecases.add(yUsecase);
        } else {}
      }
      globalYUsecases = uniqueUsecases.toList(); // For multiple values

      if (globalYUsecases.isNotEmpty) {
        await Getpreloadfield(code.value, appurl.value);
      }
      update();
    }
  }

  List getGroupsField(String label) {
    var result = labellist
        .where((field) => field.containsKey('group') && field['group'] == label)
        .toList();
    return result;
  }

  List getItemsWithoutGroup() {
    return labellist
        .where((field) => field['group'] == "" || field['group'] == null)
        .toList();
  }

  bool evaluateCondition(Map<String, String> reqBody, String condition) {
    try {
      if (condition.isEmpty) {
        return true; // If no condition, always show the field
      }

      // Regex to match potential placeholders not inside quotes
      final placeholderRegex = RegExp(r'(?<!")\b\w+\b(?!")');

      // Replace only placeholders in the condition that exist in reqBody
      String parsedCondition = condition;
      parsedCondition =
          parsedCondition.replaceAllMapped(placeholderRegex, (match) {
        String key = match.group(0)!;
        return reqBody.containsKey(key) ? '"${reqBody[key]}"' : key;
      });

      // Evaluate the parsed condition
      final bool result = _evaluateExpression(parsedCondition);

      return result;
    } catch (e) {
      return false;
    }
  }

  bool _evaluateExpression(String expression) {
    try {
      // Check for equality (==)
      if (expression.contains('==')) {
        final parts = expression.split('==').map((e) => e.trim()).toList();
        // Convert numeric strings to numbers for comparison if possible
        final left = _parseToComparable(parts[0]);
        final right = _parseToComparable(parts[1]);
        return left == right;
      }
      // Check for inequality (!=)
      if (expression.contains('!=')) {
        final parts = expression.split('!=').map((e) => e.trim()).toList();
        final left = _parseToComparable(parts[0]);
        final right = _parseToComparable(parts[1]);
        return left != right;
      }
      // Comparison operators (>=, <=, >, <)
      if (expression.contains('>=')) {
        final parts = expression.split('>=').map((e) => e.trim()).toList();
        return (double.tryParse(parts[0]) ?? 0) >=
            (double.tryParse(parts[1]) ?? 0);
      }
      if (expression.contains('<=')) {
        final parts = expression.split('<=').map((e) => e.trim()).toList();
        return (double.tryParse(parts[0]) ?? 0) <=
            (double.tryParse(parts[1]) ?? 0);
      }
      if (expression.contains('>')) {
        final parts = expression.split('>').map((e) => e.trim()).toList();
        return (double.tryParse(parts[0]) ?? 0) >
            (double.tryParse(parts[1]) ?? 0);
      }
      if (expression.contains('<')) {
        final parts = expression.split('<').map((e) => e.trim()).toList();
        return (double.tryParse(parts[0]) ?? 0) <
            (double.tryParse(parts[1]) ?? 0);
      }
      // update();
      return false;
    } catch (e) {
      return false;
    }
  }

  dynamic _parseToComparable(String value) {
    value = value.replaceAll('"', '').trim(); // Remove quotes
    // update();
    return double.tryParse(value) ??
        value; // Convert to number if possible, else keep as string
  }

  Future<void> Getpreloadfield(String name, String appurl) async {
    var res = await httpServices.Getpreloaddata(
        formname: name, appurl: appCode.value);
    if (res != null && res['success'] == true) {
      var result = res['result'] ?? {}; // Ensure result is a Map

      var useCases = globalYUsecases;
      prelaodlist.clear();

      for (var useCase in useCases) {
        if (result.containsKey(useCase)) {
          var data = result[useCase];
          if (data is List) {
            prelaodlist[useCase] =
                List.from(data); // Assign data to the specific use case
          } else {}
        } else {}
      }
    } else {}
  }
  // Add these methods to your Uiformcontroller class

// Helper method to get field value by code or label
  String? getFieldValueByCodeOrLabel(String fieldIdentifier) {
    // First try to find by label
    for (var field in labellist) {
      if (field['label']?.toString().toLowerCase() ==
          fieldIdentifier.toLowerCase()) {
        String? value = getFieldValue(field['label']);
        if (value != null && value.isNotEmpty) {
          return value;
        }
      }

      // Also try by code
      if (field['code']?.toString().toLowerCase() ==
          fieldIdentifier.toLowerCase()) {
        String? value = getFieldValue(field['label']);
        if (value != null && value.isNotEmpty) {
          return value;
        }
      }
    }

    // Check in dataMap directly
    if (dataMap.containsKey(fieldIdentifier)) {
      return dataMap[fieldIdentifier]?.toString();
    }

    return null;
  }

// Add this method to recalculate when dependent fields change
  void onFieldValueChanged(String fieldCode, String newValue) {
    // Update the field value in dataMap
    dataMap[fieldCode] = newValue;

    // Find which expressions depend on this field
    List<String> dependentExpressions = [];

    for (var field in labellist) {
      if (field['type'] == 'expression') {
        String expression = field['expression'] ?? field['rule'] ?? '';
        if (expression.contains('@$fieldCode')) {
          dependentExpressions.add(field['code']);
        }
      }
    }

    // Recalculate dependent expressions
    if (dependentExpressions.isNotEmpty) {
      print(
          '🔄 Field $fieldCode changed, recalculating: $dependentExpressions');
      updateAllExpressionFields();
    }
  }

// Enhanced expression update method
void updateAllExpressionFields() {
    print('🟢===== UPDATE ALL EXPRESSION FIELDS =====');


    int expressionCount = 0;

    for (var field in labellist) {
      if (field['type'] == 'expression') {
        expressionCount++;

        String expression = field['expression'] ?? field['rule'] ?? '';
        String label = field['label'] ?? '';

        // 👇 Expression print
        print('🧮 Field Label: $label');
        print('🧮 Expressionokkkk: $expression');

        if (expression.isNotEmpty) {
          if (!_isProcessingExpression(label)) {
            _markExpressionProcessing(label, true);

            calculateAndSetExpression(field, expression).then((_) {
              _markExpressionProcessing(label, false);
            });
          }
        }
      }
    }

    print('🟢 Total expression fields triggered: $expressionCount');
  }
// Add these helper methods to prevent infinite loops
  final Set<String> _processingExpressions = {};

  bool _isProcessingExpression(String label) {
    return _processingExpressions.contains(label);
  }

  void _markExpressionProcessing(String label, bool isProcessing) {
    if (isProcessing) {
      _processingExpressions.add(label);
    } else {
      _processingExpressions.remove(label);
    }
  }

// Update the calculateExpression method to be more robust

// Enhanced math expression evaluator
  double? _evaluateMathExpression(String expression) {
    try {
      print('🧮 Evaluating: "$expression"');

      // Remove spaces
      expression = expression.replaceAll(' ', '');

      // Handle empty expression
      if (expression.isEmpty) return 0.0;

      // Use dart:math's expression evaluation
      // This is a simple implementation - for complex expressions consider using a package

      // First handle parentheses recursively
      while (expression.contains('(')) {
        final RegExp parenRegExp = RegExp(r'\(([^\(\)]+)\)');
        final match = parenRegExp.firstMatch(expression);

        if (match != null) {
          String innerExpr = match.group(1)!;
          double? innerResult = _evaluateSimpleExpression(innerExpr);

          if (innerResult == null) return null;

          expression =
              expression.replaceFirst(match.group(0)!, innerResult.toString());
        } else {
          break;
        }
      }

      // Evaluate the final expression
      return _evaluateSimpleExpression(expression);
    } catch (e) {
      print('🧮 Math evaluation error: $e');
      return null;
    }
  }

// Evaluate simple expressions without parentheses
  double? _evaluateSimpleExpression(String expr) {
    try {
      // Handle multiplication and division first
      final RegExp multDivRegExp =
          RegExp(r'(\-?\d+\.?\d*)([*/])(\-?\d+\.?\d*)');

      while (expr.contains('*') || expr.contains('/')) {
        final match = multDivRegExp.firstMatch(expr);
        if (match != null) {
          double left = double.parse(match.group(1)!);
          double right = double.parse(match.group(3)!);
          String op = match.group(2)!;

          double result = op == '*' ? left * right : left / right;
          expr = expr.replaceFirst(match.group(0)!, result.toString());
        } else {
          break;
        }
      }

      // Handle addition and subtraction
      final RegExp addSubRegExp =
          RegExp(r'(\-?\d+\.?\d*)([+\-])(\-?\d+\.?\d*)');

      while (expr.contains('+') ||
          (expr.contains('-') && expr.lastIndexOf('-') > 0)) {
        final match = addSubRegExp.firstMatch(expr);
        if (match != null) {
          double left = double.parse(match.group(1)!);
          double right = double.parse(match.group(3)!);
          String op = match.group(2)!;

          double result = op == '+' ? left + right : left - right;
          expr = expr.replaceFirst(match.group(0)!, result.toString());
        } else {
          break;
        }
      }

      return double.tryParse(expr);
    } catch (e) {
      print('🧮 Simple evaluation error: $e');
      return null;
    }
  }

// Uiformcontroller mein expression calculation properly implement karein

  double _parseExpression(String expr) {
    // Simple parser implementation
    // Agar complex calculations hain toh 'dart_expression' package use karein

    expr = expr.replaceAll(' ', '');

    // Parentheses handle karein
    while (expr.contains('(')) {
      final RegExp parenExp = RegExp(r'\(([^()]+)\)');
      final match = parenExp.firstMatch(expr);
      if (match != null) {
        final innerResult = _parseExpression(match.group(1)!);
        expr = expr.replaceFirst(match.group(0)!, innerResult.toString());
      } else {
        break;
      }
    }

    // Multiplication/Division
    final RegExp multDivExp = RegExp(r'(\d+\.?\d*)([*/])(\d+\.?\d*)');
    while (expr.contains('*') || expr.contains('/')) {
      final match = multDivExp.firstMatch(expr);
      if (match != null) {
        final left = double.parse(match.group(1)!);
        final right = double.parse(match.group(3)!);
        final op = match.group(2)!;

        double result = op == '*' ? left * right : left / right;
        expr = expr.replaceFirst(match.group(0)!, result.toString());
      } else {
        break;
      }
    }

    // Addition/Subtraction
    final RegExp addSubExp = RegExp(r'(\d+\.?\d*)([+\-])(\d+\.?\d*)');
    while (
        expr.contains('+') || (expr.contains('-') && !expr.startsWith('-'))) {
      final match = addSubExp.firstMatch(expr);
      if (match != null) {
        final left = double.parse(match.group(1)!);
        final right = double.parse(match.group(3)!);
        final op = match.group(2)!;

        double result = op == '+' ? left + right : left - right;
        expr = expr.replaceFirst(match.group(0)!, result.toString());
      } else {
        break;
      }
    }

    return double.tryParse(expr) ?? 0.0;
  }

// Safe evaluation method
  double? _safeEval(String expression) {
    try {
      // Using dart:math's expression evaluation
      // For complex expressions, consider using a proper library
      final List<String> tokens = expression
          .split(RegExp(r'(?<=[\d)])(?=[+\-*/])|(?<=[+\-*/])(?=[\d(])'));

      // Simple implementation - for production use a proper expression parser
      // This is a basic example - you might want to use a package like 'expressions' or 'math_expressions'

      // Using a safer approach - evaluate step by step
      // For now, we'll use a simple approach
      return _parseExpression(expression);
    } catch (e) {
      return null;
    }
  }

// Method to trigger expression recalculation
  void recalculateExpressions() {
    for (var field in labellist) {
      if (field['type'] == 'expression') {
        String expression = field['expression'] ?? '';
        if (expression.isNotEmpty) {
          calculateExpression(expression).then((result) {
            if (result.isNotEmpty) {
              setFieldValue(field['label'], result);
              dataMap[field['code']] = result;
            }
          });
        }
      }
    }
  }

  Future<Map<String, dynamic>?> GetUserData(
      String code, String rule, String admissionId) async {
    try {
      Map<String, dynamic> reqBody = {
        code: admissionId.toString(),
        "collectionName": collectionName.value,
        "id": 0
      };

      if (previousResponse != null) {
        // Add only the keys from previousResponse that are not admissionId or collectionName
        previousResponse!.forEach((key, value) {
          if (key != code && key != "collectionName") {
            reqBody[key] = value;
          }
        });
      }

      // Fetch data from API
      var res = await httpServices.Getexecutedata(
        rule: rule,
        reqBody: reqBody, // Pass the prepared payload here
      );

      // Validate and update the dataMap
      if (res != null && res['success'] == true && res['result'] != null) {
        var resultData = res['result'];

        dataMap = Map<String, dynamic>.from(resultData);

        // Store the current response for future calls
        previousResponse = dataMap;

        for (var item in labellist) {
          String code = item['code'];
          String label = item['label'];

          if (dataMap.containsKey(code)) {
            var value = dataMap[code];
            setFieldValue(label, value.toString());
          }
        }

        update();
      } else {
        debugPrint(
          'Failed to fetch data. Success: ${res?['success']}, Result: ${res?['result']}',
        );
      }

      return res;
    } catch (e, stackTrace) {}
    return null;
  }

  Future<Map<String, dynamic>?> validateAndSubmitDate(
      String rule, String dischargeDate) async {
    try {
      Map<String, dynamic> reqBody = {
        "admissionId": admissionId,
        "collectionName": collectionName.value,
      };

      if (previousResponse != null) {
        // Add only the keys from previousResponse that are not admissionId or collectionName
        previousResponse!.forEach((key, value) {
          if (key != "admissionId" && key != "collectionName") {
            reqBody[key] = value;
          }
        });
      }
      reqBody['dischargeDate'] = dischargeDate; // Add/overwrite dischargeDate

      // Make API call for validation
      var res = await httpServices.Getexecutedata(
        rule: rule, // Use the current rule
        reqBody: reqBody, // Pass the constructed payload
      );

      return res;
    } catch (e, stackTrace) {
      return null;
    }
  }
}
